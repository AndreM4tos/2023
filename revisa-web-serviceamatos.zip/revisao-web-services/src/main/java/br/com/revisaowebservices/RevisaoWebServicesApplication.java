package br.com.revisaowebservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RevisaoWebServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(RevisaoWebServicesApplication.class, args);
	}

}
