package br.com.revisaowebservices.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.revisaowebservices.model.Fabricante;



public interface FabricanteRepository extends JpaRepository<Fabricante, Long> {

}
	